# Network Analysis of Harry Potter
Project in 02476 - Computational Social Science at Technical University of Denmark

To learn more about this repo and the results of the study go to the project website [here](https://wdmdev.github.io/comsocsci2021-project/).
